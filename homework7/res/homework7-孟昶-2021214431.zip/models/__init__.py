from .HCGNet_CIFAR import HCGNet_A1, HCGNet_A2, HCGNet_A3
from .HCGNet_ImageNet import HCGNet_B, HCGNet_C
